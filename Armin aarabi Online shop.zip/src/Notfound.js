import React from "react";

const Notfound = () => {
  return (
    <>
      <div
        style={{
          textAlign:'center'
        }}
      >
        <h1>Page Not found!</h1>
      </div>
    </>
  );
};

export default Notfound;
